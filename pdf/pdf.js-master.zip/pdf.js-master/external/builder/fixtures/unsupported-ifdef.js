'use strict';
//#ifdef TRUE
//ifdef should not be recognized
//#endif
var a;
