function f1() {
 "1";
 "2";
}
function f2() {
 "1";
 "2";
}
function f3() {
 if ("1") {
  "1";
 }
 "2";
 if ("3") {
  "4";
 }
}
