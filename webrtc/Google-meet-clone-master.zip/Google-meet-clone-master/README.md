# MEETY
-----
![meety](https://github.com/Allan-1/Google-meet-clone/blob/master/Images/Screenshot%20from%202021-05-17%2010-59-06.png?raw=true)

A simple google meet clone made using WEBRTC, socket.io and nodejs

# Installation & Setup

1. First install node in your system
2. Clone the repository 

    ```git https://github.com/Allan-1/Google-meet-clone.git```

3. Navigate to the directory
    ```cd Google-meet-clone```

4. Install the required dependecies
    ```npm install```

5. Run the app
    ```npm run dev```
6. Open your browser and run                
    ```localhost:3000```


# Contributions
Questions and contributions are open
