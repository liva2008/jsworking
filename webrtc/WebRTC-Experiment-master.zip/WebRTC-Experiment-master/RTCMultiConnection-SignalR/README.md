# RTCMultiConnection-SignalR
SignalR project for RTCMultiConnection

RTCMultiConnection github repository: 

* https://github.com/muaz-khan/RTCMultiConnection

# How to test?

Press F5 to run this project on Chrome, Firefox, Opera, Safari11 or Edge17.

Open two tabs; first tab should click "Open Room" button and another tab should join him using "Join Room" button.

# Files

1. RTCMultiConnection/index.html (main demo file)
2. RTCMultiConnection/SignalRConnection.js (signaling handler for javascript)
3. RTCMultiConnection/RTCMultiConnectionSignaling.cs (signalr codes)
4. RTCMultiConnection/RTCMultiConnectionHub.cs (signalr codes)
