function MultiStreamsMixer(arrayOfMediaStreams, elementClass) {
