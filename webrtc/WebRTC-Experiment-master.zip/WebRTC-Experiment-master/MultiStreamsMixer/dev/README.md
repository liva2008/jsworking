# MultiStreamsMixer | Mix Multiple Cameras & Screens into Single Stream

MultiStreamsMixer.js is separated/splitted into unique files.

This directory contains all those development files.

`grunt` tools are used to concatenate/merge all these files into `~/MultiStreamsMixer.js`.

## License

[MultiStreamsMixer.js](https://github.com/muaz-khan/MultiStreamsMixer) is released under [MIT licence](https://www.webrtc-experiment.com/licence/) . Copyright (c) [Muaz Khan](http://www.MuazKhan.com/).
