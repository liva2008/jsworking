this.startDrawingFrames = function() {
    drawVideosToCanvas();
};
